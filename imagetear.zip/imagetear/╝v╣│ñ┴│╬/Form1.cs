﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 影像切割
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private Bitmap Top_source;
        private bool Decition(int HStart, int Wstart, int Ch, int Cw, int[,] R, int[,] G, int[,] B, double Tscore)
        {
            double score=0;
            for (int i = 0; i < Ch; i++)
            {
                for (int j = 0; j < Cw; j++)
                {
                    if (R[HStart + i, Wstart + j]==B[HStart + i, Wstart + j]&&R[HStart + i, Wstart + j]==G[HStart + i, Wstart + j]&&R[HStart + i, Wstart + j]==0)
                    {
                        score += 1;
                    }
                    else  score += ((double)R[HStart + i, Wstart + j])/256;
                }
            }
            if (score>=Tscore) return true;
            else return false;
        }
        private void copyimage(int HStart, int Wstart, Bitmap target, int Ch, int Cw, int[,] R, int[,] G, int[,] B, string temp,int k)
        {
            string path="";
            for (int i = 0; i < Ch; i++)
            {
                for (int j = 0; j < Cw; j++)
                {
                    target.SetPixel(j, i, Color.FromArgb(R[HStart + i, Wstart + j], G[HStart + i, Wstart + j], B[HStart + i, Wstart + j]));
                }
            }
            if (radioButton2.Checked)
            {
                if (Decition(HStart, Wstart, Ch, Cw, R, G, B, 40))//Detect that R-value(40%up)
                {
                    path = "\\garbage";
                }
                else
                {
                    path = "\\ocean";
                }
            }
            else
            {
                path = "";
            }
            path = temp + path + "\\image" + k + ".png";
            pictureBox2.Image = target;
            FileInfo fp = new FileInfo(path);
            FileStream fs = fp.Create();
            pictureBox2.Image.Save(fs, System.Drawing.Imaging.ImageFormat.Png);
            fs.Close();
            pictureBox2.Image = null;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string folderName = System.Environment.CurrentDirectory;
            string pathString = System.IO.Path.Combine(folderName, textBox1.Text);
            System.IO.Directory.CreateDirectory(pathString);
            string folderOcean = folderName + "\\ocean_garbage";
            int i = 0;
            if (radioButton2.Checked)
            {
                string pathString2 = System.IO.Path.Combine(pathString, "ocean");
                System.IO.Directory.CreateDirectory(pathString2);
                pathString2 = System.IO.Path.Combine(pathString, "garbage");
                System.IO.Directory.CreateDirectory(pathString2);
            }
            try
            {
                if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
                {
                    for (int counter = 0; counter < 90; counter++)
                    {
                        string ocreanfile = folderOcean + "\\images (" + counter + ").jpg";
                        FileStream fs;
                        fs = new FileStream(ocreanfile, FileMode.Open, FileAccess.Read);
                        pictureBox1.Image = System.Drawing.Image.FromStream(fs);
                        fs.Close();
                        Top_source = (Bitmap)pictureBox1.Image;

                        int IH = int.Parse(textBox2.Text), IW = int.Parse(textBox3.Text);
                        int H = Top_source.Height, W = Top_source.Width;
                        Bitmap source = (Bitmap)pictureBox1.Image;
                        int[,] red = new int[source.Height, source.Width];
                        int[,] green = new int[source.Height, source.Width];
                        int[,] blue = new int[source.Height, source.Width];
                        for (int k = 0; k < source.Height; k++)
                        {
                            for (int j = 0; j < source.Width; j++)
                            {
                                red[k, j] = (int)source.GetPixel(j, k).R;
                                green[k, j] = (int)source.GetPixel(j, k).G;
                                blue[k, j] = (int)source.GetPixel(j, k).B;
                            }
                        }
                        Bitmap new2 = new Bitmap(W, H);
                        for (int k = 0; k < H; k++)
                        {
                            for (int j = 0; j < W; j++)
                            {
                                new2.SetPixel(j, k, Color.FromArgb(red[k, j], 0, 0));
                            }
                        }
                        pictureBox3.Image = new2;
                        int Ph, Pw;
                        if (H > IH && W > IW)
                        {
                            Ph = H / IH;
                            Pw = W / IW;
                            progressBar1.Minimum = 0;
                            progressBar1.Maximum = Ph * Pw;
                            progressBar1.Value = 0;
                            Bitmap new1 = new Bitmap(IH, IW);
                            for (int iH = 0; iH < H; iH += IH)//top-left
                            {
                                for (int iW = 0; iW < W; iW += IW)
                                {
                                    if (iH + IH > H || iW + IW > W)
                                    {
                                        continue;
                                    }
                                    progressBar1.Increment(1);
                                    string temp = pathString;
                                    copyimage(iH, iW, new1, IH, IW, red, green, blue, temp, i);
                                    i++;
                                }
                            }
                            if (H % IH != 0 && W % IW != 0)//bottom-right
                            {
                                for (int iH = H; iH > 0; iH -= IH)
                                {
                                    for (int iW = W; iW > 0; iW -= IW)
                                    {
                                        if (iH - IH < 0 || iW - IW < 0)
                                        {
                                            continue;
                                        }
                                        progressBar1.Increment(1);
                                        string temp = pathString;
                                        copyimage(iH - IH, iW - IW, new1, IH, IW, red, green, blue, temp, i);
                                        i++;
                                    }
                                }
                            }
                            else if (H % IH != 0)//bottom-left
                            {
                                for (int iH = H; iH > 0; iH -= IH)
                                {
                                    for (int iW = 0; iW < W; iW += IW)
                                    {
                                        if (iH - IH < 0 || iW + IW > W)
                                        {
                                            continue;
                                        }
                                        progressBar1.Increment(1);
                                        string temp = pathString;
                                        copyimage(iH - IH, iW, new1, IH, IW, red, green, blue, temp, i);
                                        i++;
                                    }
                                }
                            }
                            else if (W % IW != 0)//top-right
                            {
                                for (int iH = 0; iH < H; iH += IH)
                                {
                                    for (int iW = W; iW > 0; iW -= IW)
                                    {
                                        if (iH + IH > H || iW - IW < 0)
                                        {
                                            continue;
                                        }
                                        progressBar1.Increment(1);
                                        string temp = pathString;
                                        copyimage(iH, iW - IW, new1, IH, IW, red, green, blue, temp, i);
                                        i++;
                                    }
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Cutting area doen't match! Maybe target image is too small", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    MessageBox.Show("Finnish!!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Incorrect value!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Incorrect value!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
            
            
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Bitmap source = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = source;
                Top_source = source;
            }
        }
    }
}
